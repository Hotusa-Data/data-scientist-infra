#!/usr/bin/env python3
"""Local mock exchange-rate API. Uses only the Python standard library."""
from __future__ import annotations

import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

RATES = json.loads((Path(__file__).parent / "rates.json").read_text(encoding="utf-8"))
FAILURES = {}

class Handler(BaseHTTPRequestHandler):
    def _send(self, status: int, payload: dict) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args) -> None:
        print("[mock-api] " + fmt % args)

    def do_GET(self) -> None:
        parsed = urlparse(self.path)
        if parsed.path == "/health":
            self._send(200, {"status": "ok"})
            return

        if parsed.path != "/exchange-rates":
            self._send(404, {"error": "not_found"})
            return

        date = parse_qs(parsed.query).get("date", [None])[0]
        if not date:
            self._send(400, {"error": "missing_date"})
            return

        # Simulate one transient failure per date to test retry behaviour.
        if FAILURES.get(date, 0) == 0:
            FAILURES[date] = 1
            self._send(503, {"error": "temporary_unavailable", "date": date})
            return

        if date not in RATES:
            self._send(404, {"error": "rate_not_found", "date": date})
            return

        self._send(200, {
            "date": date,
            "base": "EUR",
            "rates_to_eur": RATES[date],
        })

if __name__ == "__main__":
    host, port = "127.0.0.1", 8000
    print(f"Mock API listening on http://{host}:{port}")
    HTTPServer((host, port), Handler).serve_forever()
